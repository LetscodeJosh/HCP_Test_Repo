========================================================================
PIMS TERRITORY RECONFIGURATION WEB PORTAL - SFE LAPTOP EDITION
========================================================================

Overview:
---------
This standalone application provides SFE (Sales Force Effectiveness) and
Admin leads with a dedicated workstation for territory reconfiguration,
rep reassignment, code renaming, and hierarchical territory tree management.

Requirements:
-------------
- Windows 10 / Windows 11 Laptop
- Any modern web browser (Google Chrome, Microsoft Edge, Brave, Firefox)
- Python 3.x (optional, bundled launcher falls back to browser automatically)

Quick Installation:
-------------------
1. Double-click "install_territory_portal.bat".
2. The installer will copy application files to your system and create a
   "Territory Reconfiguration Portal" shortcut on your Desktop.
3. Launch the portal anytime by clicking the Desktop shortcut!

Manual / Portable Execution:
----------------------------
You can also run the portal without installing:
- Double-click "run_territory_portal.bat" to start the server on http://127.0.0.1:8765.
- Or open "territory_reconfiguration_portal.html" directly in your browser.

Support:
--------
For questions or live masterlist synchronization assistance, contact the
PIMS IT / SFE Systems Team.
========================================================================
