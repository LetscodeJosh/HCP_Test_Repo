import http.server
import socketserver
import os
import urllib.parse
import json
import webbrowser
import sys

PORT = 8765
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
HTML_PATH = os.path.join(BASE_DIR, 'territory_reconfiguration_portal.html')

class TerritoryPortalHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == '/api/status':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({
                'status': 'online',
                'port': PORT,
                'version': 'V.0.5.1',
                'app_name': 'Territory Reconfiguration Portal - SFE Edition'
            }).encode('utf-8'))
            return

        if path in ['/', '/index.html', '/territory_reconfiguration_portal.html'] or not os.path.exists(path.lstrip('/')):
            try:
                with open(HTML_PATH, 'rb') as f:
                    content = f.read()
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                self.send_header('Content-Length', str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode('utf-8'))
                return

        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == '/api/sync':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({
                'status': 'success',
                'message': 'Territory reconfiguration staged and committed live.'
            }).encode('utf-8'))
            return
        self.send_response(404)
        self.end_headers()

    def log_message(self, format, *args):
        pass

def main():
    socketserver.TCPServer.allow_reuse_address = True
    print(f"============================================================")
    print(f"  PIMS • Territory Reconfiguration Portal (SFE Laptop Edition)")
    print(f"  Server listening on: http://127.0.0.1:{PORT}")
    print(f"============================================================")
    
    # Auto-open browser
    try:
        webbrowser.open(f'http://127.0.0.1:{PORT}')
    except:
        pass

    with socketserver.TCPServer(('127.0.0.1', PORT), TerritoryPortalHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server...")

if __name__ == '__main__':
    main()
