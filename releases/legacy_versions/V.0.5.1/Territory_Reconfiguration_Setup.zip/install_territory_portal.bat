@echo off
setlocal EnableDelayedExpansion
title Territory Reconfiguration Portal - SFE Laptop Installer

echo =======================================================================
echo   PIMS Territory Reconfiguration Portal - Standalone Laptop Installer
echo   Sales Force Effectiveness (SFE) Edition
echo =======================================================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\PIMS\TerritoryReconfigurationApp"

echo [1/4] Preparing application directory...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [2/4] Copying application assets...
copy /Y "%~dp0server.py" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0territory_reconfiguration_portal.html" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0run_territory_portal.bat" "%INSTALL_DIR%\" >nul

echo [3/4] Creating Windows Desktop and Start Menu shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desk = [Environment]::GetFolderPath('Desktop'); $sc = $ws.CreateShortcut(\"$desk\Territory Reconfiguration Portal.lnk\"); $sc.TargetPath = '%INSTALL_DIR%\run_territory_portal.bat'; $sc.WorkingDirectory = '%INSTALL_DIR%'; $sc.Description = 'PIMS Territory Reconfiguration Portal - SFE Edition'; $sc.Save()"

set "SM_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\PIMS"
if not exist "%SM_DIR%" mkdir "%SM_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut(\"%SM_DIR%\Territory Reconfiguration Portal.lnk\"); $sc.TargetPath = '%INSTALL_DIR%\run_territory_portal.bat'; $sc.WorkingDirectory = '%INSTALL_DIR%'; $sc.Description = 'PIMS Territory Reconfiguration Portal - SFE Edition'; $sc.Save()"

echo [4/4] Verifying installation...
if exist "%INSTALL_DIR%\territory_reconfiguration_portal.html" (
    echo.
    echo =======================================================================
    echo   INSTALLATION COMPLETED SUCCESSFULLY!
    echo.
    echo   Application installed at:
    echo   %INSTALL_DIR%
    echo.
    echo   Desktop Shortcut: "Territory Reconfiguration Portal"
    echo   Start Menu: Programs > PIMS > Territory Reconfiguration Portal
    echo =======================================================================
    echo.
    set /p LAUNCH="Would you like to launch the Territory Reconfiguration Portal now? (Y/N): "
    if /i "!LAUNCH!"=="Y" (
        start "" "%INSTALL_DIR%\run_territory_portal.bat"
    )
) else (
    echo.
    echo [ERROR] Installation failed to copy application files.
)

pause
