@echo off
title Territory Reconfiguration Portal - SFE Edition
cd /d "%~dp0"

echo ============================================================
echo   PIMS Territory Reconfiguration Portal - SFE Edition
echo   Starting local application server on port 8765...
echo ============================================================

where python >nul 2>nul
if %errorlevel% equ 0 (
    python "%~dp0server.py"
    goto end
)

where py >nul 2>nul
if %errorlevel% equ 0 (
    py "%~dp0server.py"
    goto end
)

echo.
echo Python was not detected on this system.
echo Opening portal directly in your default web browser...
start "" "%~dp0territory_reconfiguration_portal.html"

:end
pause
