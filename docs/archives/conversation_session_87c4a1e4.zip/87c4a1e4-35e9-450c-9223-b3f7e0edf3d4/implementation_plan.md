# Implementation Plan: HCP Account Monthly Validity Cycle & Territory Manager Binding

## Overview
Implement the updated ERPNext `HCP Account` monthly validity and archiving logic, and enforce dynamic territory code to read-only territory manager binding in the HCP Profiling App.

---

## Key Requirements & Technical Design

### 1. Dynamic Monthly Validity Cycle (`valid_from` & `valid_to`)
- **Month Start (`valid_from` / `start_date`)**: 1st day of the current month (`YYYY-MM-01`).
- **Month End (`valid_to` / `end_date`)**: Last day of the current month computed dynamically (`DateTime(year, month + 1, 0)`). This properly resolves 28/29 days in February (including leap years), 30 days in Apr/Jun/Sep/Nov, and 31 days in Jan/Mar/May/Jul/Aug/Oct/Dec.
- **Active vs. Archived Doctor Management**:
  - Accounts with validity within the current monthly cycle are marked **Active**.
  - Accounts past their validity period or marked inactive are managed as **Archived / Past Months**.
  - Users can filter between **Current Month Active**, **Archived / Past Months**, and **All Accounts** in [`doctor_account_screen.dart`](file:///Users/cig-it/Downloads/HCP_Test_Repo/HCP_Test_Repo/lib/screens/doctor_account_screen.dart).
  - The Account Detail modal displays a dedicated **Validity & Monthly Cycle** card with exact date range, status, and remaining cycle days.

### 2. Valid Territory Codes & Territory Manager Binding (Others Tab)
- **Territory Code Selection**: Valid territory codes loaded from ERPNext (`AD0110`, `AD0120`, `AD0130`, `AD0140`, `AD0150`, `CORE01`, `CORE02`, `NCR-01`, `NCR-02`, `All Territories`, etc.).
- **Automatic Manager Resolution**: Selecting a territory dynamically populates the associated Territory Manager (e.g. `Jorge Mengorio`).
- **Read-Only Restriction**: The Territory Manager field is strictly non-editable (`readOnly: true`) with locked styling and an informative badge.
- **Submission Binding**: Submission payload and `HCP Account` sync carry both the valid territory code and the assigned territory manager.

---

## Proposed File Changes

### Model Layer
- [MODIFY] [`lib/models/hcp_account.dart`](file:///Users/cig-it/Downloads/HCP_Test_Repo/HCP_Test_Repo/lib/models/hcp_account.dart)
  - Add `validFrom`, `validTo`, `startDate`, `endDate`, `validityPeriod`, `isArchived`, `status`.
  - Add helper functions: `calculateMonthValidFrom()`, `calculateMonthValidTo()`, `calculateMonthLabel()`, and `isCurrentMonthActive()`.
  - Update `fromJson` and `toJson` serialization.
- [MODIFY] [`lib/models/lookup_models.dart`](file:///Users/cig-it/Downloads/HCP_Test_Repo/HCP_Test_Repo/lib/models/lookup_models.dart)
  - Add `TerritoryInfo` model with `name`, `territoryName`, `territoryManager`, `program`.
- [MODIFY] [`lib/models/submission.dart`](file:///Users/cig-it/Downloads/HCP_Test_Repo/HCP_Test_Repo/lib/models/submission.dart)
  - Add `validFrom`, `validTo`, `validityPeriod`.

### Service Layer
- [MODIFY] [`lib/services/api_service.dart`](file:///Users/cig-it/Downloads/HCP_Test_Repo/HCP_Test_Repo/lib/services/api_service.dart)
  - Add `fetchTerritoryInfos()` and `getTerritoryManagerForTerritory(territoryCode)`.
  - In `syncHcpAccount` and `approveSubmission`, automatically calculate and attach dynamic `valid_from`, `valid_to`, `month_period`, `status`, and `is_active`.

### UI Screens
- [MODIFY] [`lib/screens/hcp_wizard_screen.dart`](file:///Users/cig-it/Downloads/HCP_Test_Repo/HCP_Test_Repo/lib/screens/hcp_wizard_screen.dart)
  - In the "Others" tab, make Territory Manager read-only and automatically update when Territory changes.
  - Add Monthly Validity Cycle info display.
  - Pass valid territory, territory manager, and monthly validity on submission.
- [MODIFY] [`lib/screens/doctor_account_screen.dart`](file:///Users/cig-it/Downloads/HCP_Test_Repo/HCP_Test_Repo/lib/screens/doctor_account_screen.dart)
  - Add filter for Current Month Active vs Archived vs All.
  - Display validity period badges in list rows.
  - Add Validity & Monthly Cycle section to the Account Details modal.

---

## Verification Plan
1. **Static Analysis**: Run `flutter analyze` to guarantee 0 errors and clean type safety.
2. **Build Verification**: Run `flutter build ios --release --no-codesign` and package into `PIMS_HCP_Release.ipa`.
3. **Behavioral Verification**: Verify dynamic month end calculations (e.g. Feb 28/29, Apr 30, Aug 31), read-only territory manager auto-population, and active/archive filtering.
